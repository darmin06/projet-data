# Simulate evaluation with mocked recall/ndcg
print("Recall@5 (simulated): 0.32")
print("NDCG@5 (simulated): 0.28")